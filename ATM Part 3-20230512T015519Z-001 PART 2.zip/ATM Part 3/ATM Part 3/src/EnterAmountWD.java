import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class EnterAmountWD extends javax.swing.JFrame {

    public EnterAmountWD() {
        initComponents();
        setIcon();
    }
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null, rs1=null;
    Statement stmt = null; 
    int OldBalance;
    
    int MyAccNum;
    public EnterAmountWD(int accNo) {
        initComponents();
        MyAccNum = accNo;
        Getbalance();
    }
    
    private void Getbalance()
    {
        String Query = "select * from userInfo where accNo='"+MyAccNum+"'";
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
            stmt = con.createStatement();
            rs1 = stmt.executeQuery(Query);
            if(rs1.next()){
            OldBalance = rs1.getInt(5);
            lblBalance.setText(""+OldBalance);
            }else 
            {
                //JOptionPane.showMessageDialog(this, "Wrong Account Number or PIN");
            }    
        } catch(Exception e){   
            JOptionPane.showMessageDialog(this, e);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jEditorPane1 = new javax.swing.JEditorPane();
        transaction_panel = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnExitTrans1 = new javax.swing.JButton();
        txtAmountWD = new javax.swing.JTextField();
        btnWithdrawWD = new javax.swing.JButton();
        btnCancelWD = new javax.swing.JButton();
        lblBalance = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        jScrollPane1.setViewportView(jEditorPane1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        transaction_panel.setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Enter your");

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 0));
        jLabel1.setText("WITHDRAW CASH");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("desired");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Amount");

        btnExitTrans1.setBackground(new java.awt.Color(153, 153, 255));
        btnExitTrans1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnExitTrans1.setIcon(new javax.swing.ImageIcon("C:\\Users\\villalobos\\Downloads\\icons8-back-48.png")); // NOI18N
        btnExitTrans1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitTrans1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(jLabel2)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnExitTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(33, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnExitTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(115, 115, 115)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btnWithdrawWD.setBackground(new java.awt.Color(102, 102, 255));
        btnWithdrawWD.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnWithdrawWD.setText("WITHDRAW CASH");
        btnWithdrawWD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnWithdrawWDMouseClicked(evt);
            }
        });
        btnWithdrawWD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWithdrawWDActionPerformed(evt);
            }
        });

        btnCancelWD.setBackground(new java.awt.Color(255, 51, 51));
        btnCancelWD.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnCancelWD.setText("CANCEL");
        btnCancelWD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelWDActionPerformed(evt);
            }
        });

        lblBalance.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        lblBalance.setText("BAL");

        jLabel7.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel7.setText("AMOUNT:");

        jLabel8.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel8.setText("BALANCE:");

        javax.swing.GroupLayout transaction_panelLayout = new javax.swing.GroupLayout(transaction_panel);
        transaction_panel.setLayout(transaction_panelLayout);
        transaction_panelLayout.setHorizontalGroup(
            transaction_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transaction_panelLayout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(transaction_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(transaction_panelLayout.createSequentialGroup()
                        .addGap(112, 112, 112)
                        .addGroup(transaction_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnCancelWD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnWithdrawWD, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(transaction_panelLayout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(txtAmountWD, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(transaction_panelLayout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jLabel7))
                    .addGroup(transaction_panelLayout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblBalance)))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        transaction_panelLayout.setVerticalGroup(
            transaction_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(transaction_panelLayout.createSequentialGroup()
                .addGap(73, 73, 73)
                .addGroup(transaction_panelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblBalance)
                    .addComponent(jLabel8))
                .addGap(52, 52, 52)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtAmountWD, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnWithdrawWD, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnCancelWD, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(104, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(transaction_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(transaction_panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnWithdrawWDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWithdrawWDActionPerformed
       
    }//GEN-LAST:event_btnWithdrawWDActionPerformed

    private void btnExitTrans1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitTrans1ActionPerformed
        this.setVisible(false);
        new login2().setVisible(true);
    }//GEN-LAST:event_btnExitTrans1ActionPerformed

    private void btnWithdrawWDMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnWithdrawWDMouseClicked
        if(txtAmountWD.getText().isEmpty() || txtAmountWD.getText().equals(0))
        {
            JOptionPane.showMessageDialog(this, "Enter Valid Amount");
        }else if(OldBalance < Integer.valueOf(txtAmountWD.getText()))
        {
            JOptionPane.showMessageDialog(this, "Sobra boss");
        }else
        {
            
            try {
            String Query = "Update userInfo set balance=? where accNo=?";
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
            PreparedStatement ps = con.prepareStatement(Query);
            ps.setInt(1, OldBalance - Integer.valueOf(txtAmountWD.getText()));
            ps.setInt(2, MyAccNum);
            if(ps.executeUpdate()==1)
            {
                JOptionPane.showMessageDialog(this, "Balance Updated");
            }else
            {
                JOptionPane.showMessageDialog(this, "Missing Information");
            }
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }
        }
    }//GEN-LAST:event_btnWithdrawWDMouseClicked
    
     private void Clear()
    {
      txtAmountWD.setText("");
    }
    private void btnCancelWDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelWDActionPerformed
       Clear();
    }//GEN-LAST:event_btnCancelWDActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EnterAmountWD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EnterAmountWD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EnterAmountWD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EnterAmountWD.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EnterAmountWD().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCancelWD;
    private javax.swing.JButton btnExitTrans1;
    private javax.swing.JButton btnWithdrawWD;
    private javax.swing.JEditorPane jEditorPane1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblBalance;
    private javax.swing.JPanel transaction_panel;
    private javax.swing.JTextField txtAmountWD;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("atm.png"))); 
    }
}
