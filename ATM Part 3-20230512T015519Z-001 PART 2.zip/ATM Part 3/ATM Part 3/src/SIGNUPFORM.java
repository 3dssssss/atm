import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;


public class SIGNUPFORM extends javax.swing.JFrame {
    
    public SIGNUPFORM() {
        initComponents();
        setIcon();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        panelsignU = new javax.swing.JPanel();
        txtAccNum = new javax.swing.JTextField();
        lblAcc = new javax.swing.JLabel();
        lblName = new javax.swing.JLabel();
        lblAdd = new javax.swing.JLabel();
        lblPIN = new javax.swing.JLabel();
        lblPnum = new javax.swing.JLabel();
        txtName = new javax.swing.JTextField();
        txtAdd = new javax.swing.JTextField();
        txtPin = new javax.swing.JTextField();
        txtPNum = new javax.swing.JTextField();
        Name = new javax.swing.JLabel();
        btnSubmit = new javax.swing.JButton();
        btnBack = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelsignU.setBackground(new java.awt.Color(0, 0, 102));

        lblAcc.setBackground(new java.awt.Color(255, 255, 255));
        lblAcc.setForeground(new java.awt.Color(240, 240, 240));
        lblAcc.setText("Account Number");

        lblName.setBackground(new java.awt.Color(255, 255, 255));
        lblName.setForeground(new java.awt.Color(240, 240, 240));
        lblName.setText("Name");

        lblAdd.setBackground(new java.awt.Color(255, 255, 255));
        lblAdd.setForeground(new java.awt.Color(240, 240, 240));
        lblAdd.setText("Address");

        lblPIN.setBackground(new java.awt.Color(255, 255, 255));
        lblPIN.setForeground(new java.awt.Color(240, 240, 240));
        lblPIN.setText("PIN");

        lblPnum.setBackground(new java.awt.Color(255, 255, 255));
        lblPnum.setForeground(new java.awt.Color(240, 240, 240));
        lblPnum.setText("Phone Number");

        Name.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        Name.setForeground(new java.awt.Color(255, 204, 0));
        Name.setText("ODB ProMax");

        btnSubmit.setBackground(new java.awt.Color(0, 153, 0));
        btnSubmit.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnSubmit.setText("SUBMIT");
        btnSubmit.setActionCommand("LOG IN");
        btnSubmit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSubmitMouseClicked(evt);
            }
        });
        btnSubmit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSubmitActionPerformed(evt);
            }
        });

        btnBack.setBackground(new java.awt.Color(153, 153, 255));
        btnBack.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnBack.setIcon(new javax.swing.ImageIcon("C:\\Users\\villalobos\\Downloads\\icons8-back-48.png")); // NOI18N
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelsignULayout = new javax.swing.GroupLayout(panelsignU);
        panelsignU.setLayout(panelsignULayout);
        panelsignULayout.setHorizontalGroup(
            panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelsignULayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblAcc)
                    .addComponent(lblName)
                    .addComponent(lblAdd)
                    .addComponent(lblPIN)
                    .addComponent(lblPnum))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnSubmit, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(txtPNum)
                        .addComponent(txtPin)
                        .addComponent(txtName)
                        .addComponent(txtAccNum)
                        .addComponent(txtAdd, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(154, Short.MAX_VALUE))
        );
        panelsignULayout.setVerticalGroup(
            panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelsignULayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Name, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtAccNum, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAcc))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblName)
                    .addComponent(txtName, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPIN)
                    .addComponent(txtPin, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblPnum)
                    .addComponent(txtPNum, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(panelsignULayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtAdd, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblAdd))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnSubmit)
                .addContainerGap(53, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelsignU, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelsignU, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnSubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSubmitActionPerformed
        
    }//GEN-LAST:event_btnSubmitActionPerformed

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        this.setVisible(false);
        new login2().setVisible(true);
    }//GEN-LAST:event_btnBackActionPerformed
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    Statement stmt = null; 
    private void Clear()
    {
      txtAccNum.setText("");
      txtName.setText("");
      txtPin.setText("");
      txtPNum.setText("");
      txtAdd.setText("");
    }
    
    private void btnSubmitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSubmitMouseClicked
        
        if(txtAccNum.getText().isEmpty() || txtName.getText().isEmpty() || txtPNum.getText().isEmpty() || txtAdd.getText().isEmpty() || txtPin.getText().isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Missing Information");
            
        }else{
            try{
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
               PreparedStatement Add = con.prepareStatement("insert into userInfo values(?,?,?,?,?,?)");
               Add.setInt(1, Integer.valueOf(txtAccNum.getText()));
               Add.setString(2, txtName.getText());
               Add.setString(3, txtPNum.getText());
               Add.setString(4, txtAdd.getText());
               Add.setInt(5,0);
               Add.setInt(6,Integer.valueOf(txtPin.getText()));
               int row = Add.executeUpdate();
               JOptionPane.showMessageDialog(this, "Account Saved");
               con.close();
               Clear();
            }catch(Exception e) {
                JOptionPane.showMessageDialog(this, e);
            }
      }
    }//GEN-LAST:event_btnSubmitMouseClicked
 
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SIGNUPFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SIGNUPFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SIGNUPFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SIGNUPFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SIGNUPFORM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Name;
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnSubmit;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblAcc;
    private javax.swing.JLabel lblAdd;
    private javax.swing.JLabel lblName;
    private javax.swing.JLabel lblPIN;
    private javax.swing.JLabel lblPnum;
    private javax.swing.JPanel panelsignU;
    private javax.swing.JTextField txtAccNum;
    private javax.swing.JTextField txtAdd;
    private javax.swing.JTextField txtName;
    private javax.swing.JTextField txtPNum;
    private javax.swing.JTextField txtPin;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("atm.png")));
    }
}
