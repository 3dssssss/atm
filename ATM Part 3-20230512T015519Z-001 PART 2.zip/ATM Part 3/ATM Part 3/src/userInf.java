/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Danielle Dela Cruz
 */
public class userInf {
    private int accNo;
    private String name;
    private int phoneNo;
    private int pin;
    private String address;
    
    public userInf(int accNo, String name, int phoneNo, int pin, String address){
        this.accNo = accNo;
        this.name = name;
        this.phoneNo = phoneNo;
        this.pin = pin;
        this.address = address;
    }
    
    public String getName(){
        return name;
    }
    
    public void setName(String uName){
        uName = name;
    }
    
    public int getAccNo(){
        return accNo;
    }
    public void setAccNo(int uAccNo){
        uAccNo = accNo;
    }
    
    public int getPhoneNo(){
        return phoneNo;
    }
    public void setPhoneNo(int uPhoneNo){
        uPhoneNo = phoneNo;
    }
    
    public String getAddress(){
        return address;
    }
    public void setAddress(String uAddress){
        uAddress = address;
    }
    
    public int getPin(){
        return pin;
    }
    public void setPin(int uPin){
        uPin = pin;
    }

}
