import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class BALANCEINQFORM extends javax.swing.JFrame {

    /**
     * Creates new form BALANCEINQFORM
     */
    public BALANCEINQFORM() {
        initComponents();
        setIcon();
    }

   int MyAccNum;
    public BALANCEINQFORM(int accNo) {
        initComponents();
        MyAccNum = accNo;
        lblAccNum.setText(""+accNo);
        Getbalance();
    }
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null, rs1=null;
    Statement stmt1 = null; 
    int OldBalance;
    
    private void Getbalance()
    {
        String Query = "select * from userInfo where accNo='"+MyAccNum+"'";
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
            stmt1 = con.createStatement();
            rs1 = stmt1.executeQuery(Query);
            if(rs1.next()){
            OldBalance = rs1.getInt(5);
            lblBalance3.setText(""+OldBalance);
            }else 
            {
                //JOptionPane.showMessageDialog(this, "Wrong Account Number or PIN");
            }    
        } catch(Exception e){   
            JOptionPane.showMessageDialog(this, e);
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        lblBalance2 = new javax.swing.JLabel();
        lblBalance = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnExitTrans1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblAccNum = new javax.swing.JLabel();
        lblBalance3 = new javax.swing.JLabel();

        jLabel2.setText("jLabel2");

        lblBalance2.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        lblBalance2.setText("BAL");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblBalance.setBackground(new java.awt.Color(0, 0, 102));
        lblBalance.setName("BALANCE"); // NOI18N

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 204, 0));
        jLabel1.setText("BALANCE");

        btnExitTrans1.setBackground(new java.awt.Color(0, 0, 153));
        btnExitTrans1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnExitTrans1.setIcon(new javax.swing.ImageIcon("C:\\Users\\villalobos\\Downloads\\icons8-back-48.png")); // NOI18N
        btnExitTrans1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitTrans1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lblBalanceLayout = new javax.swing.GroupLayout(lblBalance);
        lblBalance.setLayout(lblBalanceLayout);
        lblBalanceLayout.setHorizontalGroup(
            lblBalanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblBalanceLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(lblBalanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(btnExitTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        lblBalanceLayout.setVerticalGroup(
            lblBalanceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lblBalanceLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnExitTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(111, 111, 111)
                .addComponent(jLabel1)
                .addContainerGap(144, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel3.setText("TOTAL BALANCE:");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        jLabel4.setText("ACCOUNT NUMBER:");

        lblAccNum.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        lblAccNum.setForeground(new java.awt.Color(255, 51, 51));
        lblAccNum.setText("BAL");

        lblBalance3.setFont(new java.awt.Font("Arial", 1, 20)); // NOI18N
        lblBalance3.setForeground(new java.awt.Color(255, 51, 51));
        lblBalance3.setText("BAL");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(lblBalance, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(lblBalance3))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblAccNum)))
                .addContainerGap(80, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblBalance, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lblAccNum))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lblBalance3))
                .addGap(119, 119, 119))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnExitTrans1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitTrans1ActionPerformed
        this.setVisible(false);
        new login2().setVisible(true);
    }//GEN-LAST:event_btnExitTrans1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BALANCEINQFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BALANCEINQFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BALANCEINQFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BALANCEINQFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BALANCEINQFORM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnExitTrans1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel lblAccNum;
    private javax.swing.JPanel lblBalance;
    private javax.swing.JLabel lblBalance2;
    private javax.swing.JLabel lblBalance3;
    // End of variables declaration//GEN-END:variables

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("atm.png")));
    }
}
