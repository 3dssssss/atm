import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;


public class DEPOSITFORM extends javax.swing.JFrame {

    public DEPOSITFORM() {
        initComponents();
        //setIcon();
    }
    
    int MyAccNum;
    public DEPOSITFORM(int accNo) {
        initComponents();
        MyAccNum = accNo;
        lblAccNum1.setText(""+MyAccNum);
        Getbalance();
        setIcon();
    }
    
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null, rs1=null;
    Statement stmt1 = null; 
    int OldBalance;
    
    private void Getbalance()
    {
        String Query = "select * from userInfo where accNo='"+MyAccNum+"'";
        try{
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
            stmt1 = con.createStatement();
            rs1 = stmt1.executeQuery(Query);
            if(rs1.next()){
            OldBalance = rs1.getInt(5);
            }else 
            {
                //JOptionPane.showMessageDialog(this, "Wrong Account Number or PIN");
            }    
        } catch(Exception e){   
            JOptionPane.showMessageDialog(this, e);
        }
    }
    String myDate;
    public void getDate() {
        Date d = new Date();
        SimpleDateFormat s = new SimpleDateFormat("dd-MM-yy");
        String myDate = s.format(d);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btnDeposit = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        lblDeposit = new javax.swing.JLabel();
        btnBACKTrans1 = new javax.swing.JButton();
        lblAmount = new javax.swing.JLabel();
        txtAmount = new javax.swing.JTextField();
        lblAccNum1 = new javax.swing.JLabel();
        lblAccNum = new javax.swing.JLabel();

        jLabel1.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnDeposit.setBackground(new java.awt.Color(153, 153, 153));
        btnDeposit.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnDeposit.setText("DEPOSIT");
        btnDeposit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnDepositMouseClicked(evt);
            }
        });
        btnDeposit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDepositActionPerformed(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        lblDeposit.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblDeposit.setForeground(new java.awt.Color(255, 204, 0));
        lblDeposit.setText("DEPOSIT CASH");

        btnBACKTrans1.setBackground(new java.awt.Color(153, 153, 255));
        btnBACKTrans1.setFont(new java.awt.Font("Arial", 1, 12)); // NOI18N
        btnBACKTrans1.setIcon(new javax.swing.ImageIcon("C:\\Users\\villalobos\\Downloads\\icons8-back-48.png")); // NOI18N
        btnBACKTrans1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBACKTrans1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnBACKTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblDeposit))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBACKTrans1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(114, 114, 114)
                .addComponent(lblDeposit)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblAmount.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblAmount.setText("AMOUNT:");

        txtAmount.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N

        lblAccNum1.setFont(new java.awt.Font("Tahoma", 2, 22)); // NOI18N
        lblAccNum1.setForeground(new java.awt.Color(255, 51, 51));
        lblAccNum1.setText("jLabel1");

        lblAccNum.setFont(new java.awt.Font("Tahoma", 2, 21)); // NOI18N
        lblAccNum.setText("Account Number:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(57, 57, 57)
                                .addComponent(lblAccNum)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAccNum1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(69, 69, 69)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblAmount))
                                    .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addContainerGap(58, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnDeposit, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(110, 110, 110))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblAccNum)
                    .addComponent(lblAccNum1))
                .addGap(52, 52, 52)
                .addComponent(lblAmount)
                .addGap(13, 13, 13)
                .addComponent(txtAmount, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnDeposit)
                .addContainerGap(132, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnDepositActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDepositActionPerformed

    }//GEN-LAST:event_btnDepositActionPerformed

    private void btnBACKTrans1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBACKTrans1ActionPerformed
        this.setVisible(false);
        new login2().setVisible(true);
    }//GEN-LAST:event_btnBACKTrans1ActionPerformed
    private void DepositMoney() {
        try{
               getDate();
               con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
               PreparedStatement Add = con.prepareStatement("insert into tbltransaction values(?,?,?,?,?)");
               Add.setInt(1, 1);
               Add.setInt(2, MyAccNum);
               Add.setString(3, "Deposit");
               Add.setString(4, txtAmount.getText());
               Add.setString(5,myDate); 
               int row = Add.executeUpdate();
               con.close();
               //Clear();
            }catch(Exception e) {
                JOptionPane.showMessageDialog(this, e);
            }
    }
    private void btnDepositMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnDepositMouseClicked
        if(txtAmount.getText().isEmpty() || txtAmount.getText().equals(0))
        {
            JOptionPane.showMessageDialog(this, "Enter Valid Amount");
        }else
        {
            try {
            String Query = "Update userInfo set balance=? where accNo=?";
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbatm", "root","");
            PreparedStatement ps = con.prepareStatement(Query);
            ps.setInt(1, OldBalance + Integer.valueOf(txtAmount.getText()));
            ps.setInt(2, MyAccNum);
            if(ps.executeUpdate()==1)
            {
                JOptionPane.showMessageDialog(this, "Balance Updated");
                DepositMoney();
            }else
            {
                JOptionPane.showMessageDialog(this, "Missing Information");
            }
            }catch(Exception e){
                JOptionPane.showMessageDialog(this, e);
            }
        }
    }//GEN-LAST:event_btnDepositMouseClicked

    private void setIcon() {
        setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("atm.png")));
    }
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DEPOSITFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DEPOSITFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DEPOSITFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DEPOSITFORM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DEPOSITFORM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBACKTrans1;
    private javax.swing.JButton btnDeposit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblAccNum;
    private javax.swing.JLabel lblAccNum1;
    private javax.swing.JLabel lblAmount;
    private javax.swing.JLabel lblDeposit;
    private javax.swing.JTextField txtAmount;
    // End of variables declaration//GEN-END:variables

    
}
