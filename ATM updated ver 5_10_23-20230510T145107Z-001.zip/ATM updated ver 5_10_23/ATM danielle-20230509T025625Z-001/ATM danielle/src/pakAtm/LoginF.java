package pakAtm;

/**
 *
 * @author Acer
 */
public class LoginF {
    
    public static void main(String[] args) {
        new LOGINFORM().setVisible(true);
    }
}
