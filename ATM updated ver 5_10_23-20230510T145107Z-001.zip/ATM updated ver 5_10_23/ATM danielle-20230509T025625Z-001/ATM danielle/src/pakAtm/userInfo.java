package pakAtm;

public class userInfo {
    
    private int AccNo;
    private String name;
    private int pin;
    private int phoneNum;
    private String address;
   
    
    public userInfo( int AccNo, String name, int pin, int phoneNum, String address ){
       
        this.AccNo = AccNo;
        this.name = name;
        this.pin = pin;
        this.phoneNum = phoneNum;
        this.address = address;
        
    }
    
    
    public int getAccNo(){
        return AccNo;
    }
    public void setAccNo(int uAccNo){
        AccNo = uAccNo;
    }
    
     public String getname(){
        return name;
    }
    public void setname(String uName){
        name = uName;
    }
    
      public int getpin(){
        return pin;
    }
    public void setpin(int uPin){
        pin = uPin;
    }
    
    public int getphoneNum(){
        return phoneNum;
    }
    public void setphoneNum(int uPhoneNum){
        phoneNum = uPhoneNum;
    }
    
    public String getaddress(){
        return address;
    }
    public void setaddress(String uAddress){
        address = uAddress;
    }
    
}